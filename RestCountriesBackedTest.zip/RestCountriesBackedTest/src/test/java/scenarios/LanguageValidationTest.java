package scenarios;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.ApiUtils;

import java.util.List;
import java.util.Map;

import static io.restassured.RestAssured.given;

public class LanguageValidationTest {


    @Test
    public void languageValidationTest() {

        Response response = ApiUtils.getAllCountries();
        List<Map<String, Object>> countries = response.jsonPath().getList("$");

        boolean found = countries.stream()
                .filter(c -> ((Map<?, ?>)c.get("translations")).toString().contains("South Africa"))
                .anyMatch(c -> {
                    Map<String, String> languages = (Map<String, String>) c.get("languages");
                    return languages != null && languages.containsValue("South African Sign Language");
                });

        Assert.assertEquals(found, "SASL not found for South Africa");
    }
}
