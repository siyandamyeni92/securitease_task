package scenarios;

import io.restassured.response.Response;
import org.testng.annotations.Test;
import utils.ApiUtils;

import static io.restassured.RestAssured.given;
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

public class SchemaValidationTest {

    @Test
    public void schemaValidationTest() {

        Response response = ApiUtils.getAllCountries();
        response.then().assertThat().statusCode(200).body("[0]",matchesJsonSchemaInClasspath("schema/country-schema.json"));
    }
}
