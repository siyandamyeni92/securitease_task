package scenarios;

import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.Test;
import utils.ApiUtils;

import java.util.List;


public class CountryCountTest {

    @Test
    public void countryCountTest() {

        Response response = ApiUtils.getAllCountries();
        List<?> countries = response.jsonPath().getList("$");
        Assert.assertEquals(countries.size(), 195);
    }
}
