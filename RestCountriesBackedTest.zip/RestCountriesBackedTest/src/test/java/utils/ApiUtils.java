package utils;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ApiUtils {

    public static final String BASE_URL = "https://restcountries.com/v3.1";

    public static Response getAllCountries() {
        return RestAssured
                .given()
                .baseUri(BASE_URL)
                .basePath("/all")
                .queryParam("fields", "name,languages,capital,region")
                .when()
                .get();
    }
}
