package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.testng.Assert;
import pages.BBCSearchPage;
import utils.DriverManager;

public class BBCSearchPageSteps {

    BBCSearchPage searchPage = new BBCSearchPage(DriverManager.getDriver());

    @Given("I am on the BBC homepage")
    public void goToHomePage() {
        DriverManager.getDriver().get("https://www.bbc.com/sport");
    }

    @When("I search for {string}")
    public void iSearchFor(String keyword) {
        searchPage.searchFor(keyword);
    }

    @Then("at least {int} relevant results should be displayed")
    public void atLeastXResultsDisplayed(int expectedMinimum) {
        int count = searchPage.getSearchResultsCount();
        System.out.println(count);
       Assert.assertTrue(count >= expectedMinimum);
    }
}
