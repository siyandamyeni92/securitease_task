package stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.testng.Assert;
import pages.BBCResultsPage;
import utils.DriverManager;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class BBCResultsPageSteps {

    BBCResultsPage resultsPage = new BBCResultsPage(DriverManager.getDriver());
    Map<String, String> actualResults;

    @Given("I am on the BBC Formula 1 results page for Las Vegas 2023")
    public void openLasVegasResultsPage() {
        DriverManager.getDriver().get("https://www.bbc.com/sport");
        DriverManager.getDriver().findElement(By.xpath("//span[text()='Formula 1']")).click();
        DriverManager.getDriver().findElement(By.xpath("//span[text()='Results']")).click();
        DriverManager.getDriver().findElement(By.xpath("//div[text()='2023']")).click();
        DriverManager.getDriver().findElement(By.xpath("//span[text()='Las Vegas Grand Prix, Las Vegas Street Circuit']")).click();
    }

    @When("I read the top 3 results from the table")
    public void readTopThree() {
        actualResults = resultsPage.getTopThreeResults();
    }

    @Then("the results should be:")
    public void validateResults(io.cucumber.datatable.DataTable dataTable) {
        List<Map<String, String>> rows = dataTable.asMaps(String.class, String.class);
        Map<String, String> expected = new LinkedHashMap<>();
        for (Map<String, String> row : rows) {
            expected.put(row.get("Position"), row.get("Driver"));
        }
        Assert.assertEquals(expected, actualResults);
    }
}


