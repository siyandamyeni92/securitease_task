package stepdefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import utils.DriverManager;

public class Hooks {

    @Before
    public void setup() {
        DriverManager.getDriver(); // launches browser
    }

    @After
    public void teardown() {
        DriverManager.quitDriver(); // closes browser
    }
}
