package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.LinkedHashMap;
import java.util.Map;

public class BBCResultsPage {

    WebDriver driver;
    String resultsTable =
            "//span[text()='Las Vegas Grand Prix, Las Vegas Street Circuit']/ancestor::h2/following-sibling::div//table//tbody//tr[";

    public BBCResultsPage(WebDriver driver) {
        this.driver = driver;
    }

    public Map<String, String> getTopThreeResults() {
        Map<String, String> results = new LinkedHashMap<>();
        for (int i = 1; i <= 3; i++) {
            String position = i == 1 ? "1st" : i == 2 ? "2nd" : "3rd";
            String driverName = driver.findElement(By.xpath(resultsTable+ i +"]/td[2]//span[contains(@class,'-FullName')]")).getText();
            results.put(position, driverName.trim());
        }
        return results;
    }
}
