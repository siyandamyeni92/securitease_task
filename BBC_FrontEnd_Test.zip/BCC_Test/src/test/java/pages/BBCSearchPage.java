package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import utils.DriverManager;

import java.time.Duration;
import java.util.List;

public class BBCSearchPage {

    WebDriver driver;
    WebDriverWait wait;

    public BBCSearchPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10000));
    }

    By searchIcon = By.xpath("//span[text()='Search BBC']");;
    By searchInput = By.id("searchInput");
    By searchButton = By.xpath("//button[text()='Search']");
    By searchResults = By.xpath("//ul[contains(@class,'-Stack')]/li");

    public void searchFor(String keyword) {
        driver.findElement(searchIcon).click();
        driver.findElement(searchInput).sendKeys(keyword);
        driver.findElement(searchButton).click();
    }

    public int getSearchResultsCount() {
        wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(searchResults));
        List<WebElement> results = driver.findElements(searchResults);
        return results.size();
    }
}
